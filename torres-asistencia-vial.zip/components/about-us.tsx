"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import Image from "next/image"

export default function AboutUs() {
  const sectionRef = useRef(null)
  const isInView = useInView(sectionRef, { once: true, amount: 0.3 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  }

  return (
    <section id="about" ref={sectionRef} className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="max-w-6xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
              Our <span className="text-red-500 dark:text-red-500">Story</span>
            </h2>
            <div className="w-20 h-1 bg-yellow-500 mx-auto mb-6"></div>
            <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
              From tow trucks to racing cars, our journey has been driven by passion and commitment to excellence.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div variants={itemVariants} className="relative">
              <div className="relative h-[400px] overflow-hidden rounded-lg shadow-xl">
                <Image
                  src="/placeholder.svg?height=800&width=600"
                  alt="Old family tow truck"
                  fill
                  className="object-cover object-center"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-yellow-500 text-black p-4 rounded-lg shadow-lg">
                <p className="font-bold">Est. 1985</p>
                <p>Family Business</p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants}>
              <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">From Humble Beginnings</h3>
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                Torres Asistencia Vial began as a small family business with a single tow truck. Armando Torres Sr.
                started the company with a simple mission: to provide reliable roadside assistance to those in need.
              </p>
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                Over the years, our commitment to quality service and quick response times has allowed us to grow into
                one of the region's most trusted towing services.
              </p>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-1 bg-red-500"></div>
                <p className="text-lg font-semibold text-gray-900 dark:text-white">35+ years of experience</p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="md:order-4">
              <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Racing in Our Blood</h3>
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                The passion for machines that drove our towing business naturally extended to motorsports. Armando
                Torres Jr. took this passion to the next level by competing in TC Cuatromil, bringing the same
                dedication and technical expertise from our roadside assistance to the racetrack.
              </p>
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                Today, our racing team represents the speed, precision, and reliability that defines our business
                values.
              </p>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-1 bg-red-500"></div>
                <p className="text-lg font-semibold text-gray-900 dark:text-white">TC Cuatromil competitors</p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="relative md:order-3">
              <div className="relative h-[400px] overflow-hidden rounded-lg shadow-xl">
                <Image
                  src="/placeholder.svg?height=800&width=600"
                  alt="Modern racing car"
                  fill
                  className="object-cover object-center"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-red-500 text-white p-4 rounded-lg shadow-lg">
                <p className="font-bold">Present Day</p>
                <p>Racing Excellence</p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
