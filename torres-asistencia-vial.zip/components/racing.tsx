"use client"

import { motion, useScroll, useTransform } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Calendar, Trophy, Settings, Instagram } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Racing() {
  const sectionRef = useRef(null)
  const isInView = useInView(sectionRef, { once: true, amount: 0.1 })
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], [100, -100])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  }

  const races = [
    { date: "Mar 15, 2023", track: "Autódromo Roberto Mouras", position: "2nd" },
    { date: "Apr 22, 2023", track: "Circuito de Buenos Aires", position: "1st" },
    { date: "May 10, 2023", track: "Autódromo Oscar Cabalén", position: "3rd" },
    { date: "Jun 18, 2023", track: "Autódromo Juan Manuel Fangio", position: "1st" },
    { date: "Jul 30, 2023", track: "Autódromo Ciudad de Paraná", position: "4th" },
  ]

  const sponsors = ["Sponsor 1", "Sponsor 2", "Sponsor 3", "Sponsor 4", "Sponsor 5", "Sponsor 6"]

  const carSpecs = [
    { label: "Engine", value: "2.0L Turbocharged" },
    { label: "Horsepower", value: "350 HP" },
    { label: "Transmission", value: "6-Speed Sequential" },
    { label: "Weight", value: "1,100 kg" },
    { label: "0-100 km/h", value: "4.2 seconds" },
    { label: "Top Speed", value: "260 km/h" },
  ]

  return (
    <section id="racing" ref={sectionRef} className="py-20 bg-black text-white overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="max-w-6xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              TC <span className="text-red-500">Cuatromil</span>
            </h2>
            <div className="w-20 h-1 bg-yellow-500 mx-auto mb-6"></div>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Where our passion for machines meets the thrill of competition.
            </p>
          </motion.div>

          <div className="relative mb-20">
            <motion.div className="absolute inset-0 -z-10" style={{ y }}>
              <div className="h-full w-full">
                <Image
                  src="/placeholder.svg?height=800&width=1600"
                  alt="Racing car in action"
                  fill
                  className="object-cover object-center opacity-40"
                />
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center py-12">
              <div className="order-2 md:order-1">
                <h3 className="text-2xl font-bold mb-6">Racing with Precision</h3>
                <p className="text-gray-300 mb-6">
                  Armando Torres brings the same dedication and technical expertise from our roadside assistance to the
                  racetrack. Our TC Cuatromil team represents the speed, precision, and reliability that defines our
                  business values.
                </p>
                <div className="flex flex-wrap gap-4 mb-8">
                  {["Speed", "Precision", "Reliability", "Passion"].map((value, index) => (
                    <span key={index} className="px-4 py-2 bg-red-500 text-white rounded-full text-sm font-medium">
                      {value}
                    </span>
                  ))}
                </div>
                <Button className="bg-red-500 hover:bg-red-600 text-white">
                  View Race Schedule
                  <Calendar className="ml-2 h-5 w-5" />
                </Button>
              </div>
              <div className="order-1 md:order-2 relative">
                <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
                  <Image
                    src="/placeholder.svg?height=800&width=600"
                    alt="Racing car"
                    fill
                    className="object-cover object-center"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
                    <p className="text-white text-lg font-bold">#27 Armando Torres</p>
                    <p className="text-gray-200">TC Cuatromil Championship</p>
                  </div>
                </div>
                <div className="absolute -bottom-6 -right-6 bg-yellow-500 text-black p-4 rounded-lg shadow-lg">
                  <Trophy className="h-6 w-6" />
                  <p className="font-bold mt-1">2022 Champion</p>
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div variants={itemVariants}>
            <Tabs defaultValue="schedule" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger value="schedule" className="text-lg">
                  Race Schedule
                </TabsTrigger>
                <TabsTrigger value="specs" className="text-lg">
                  Car Specs
                </TabsTrigger>
                <TabsTrigger value="sponsors" className="text-lg">
                  Sponsors
                </TabsTrigger>
              </TabsList>

              <TabsContent value="schedule" className="mt-0">
                <div className="bg-gray-900 rounded-lg p-6">
                  <h3 className="text-xl font-bold mb-6 flex items-center">
                    <Calendar className="mr-2 h-5 w-5 text-red-500" />
                    Recent Race Results
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {races.map((race, index) => (
                      <Card key={index} className="bg-gray-800 border-none">
                        <CardContent className="p-4 flex justify-between items-center">
                          <div>
                            <p className="text-gray-400 text-sm">{race.date}</p>
                            <p className="font-medium">{race.track}</p>
                          </div>
                          <div
                            className={`px-3 py-1 rounded-full text-sm font-medium ${
                              race.position === "1st"
                                ? "bg-yellow-500 text-black"
                                : race.position === "2nd"
                                  ? "bg-gray-300 text-black"
                                  : race.position === "3rd"
                                    ? "bg-yellow-700 text-white"
                                    : "bg-gray-700 text-white"
                            }`}
                          >
                            {race.position}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="specs" className="mt-0">
                <div className="bg-gray-900 rounded-lg p-6">
                  <h3 className="text-xl font-bold mb-6 flex items-center">
                    <Settings className="mr-2 h-5 w-5 text-red-500" />
                    Car Specifications
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {carSpecs.map((spec, index) => (
                      <div key={index} className="bg-gray-800 p-4 rounded-lg">
                        <p className="text-gray-400 text-sm">{spec.label}</p>
                        <p className="font-bold text-lg">{spec.value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="sponsors" className="mt-0">
                <div className="bg-gray-900 rounded-lg p-6">
                  <h3 className="text-xl font-bold mb-6">Our Sponsors</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6">
                    {sponsors.map((sponsor, index) => (
                      <div key={index} className="bg-gray-800 p-4 rounded-lg flex items-center justify-center h-24">
                        <p className="font-medium text-center">{sponsor}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </motion.div>

          <motion.div variants={itemVariants} className="mt-16 text-center">
            <h3 className="text-xl font-bold mb-4 flex items-center justify-center">
              <Instagram className="mr-2 h-5 w-5 text-red-500" />
              Follow Our Racing Journey
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((item) => (
                <div key={item} className="relative h-64 rounded-lg overflow-hidden group">
                  <Image
                    src={`/placeholder.svg?height=400&width=400&text=Instagram+${item}`}
                    alt={`Instagram post ${item}`}
                    fill
                    className="object-cover object-center group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                    <div className="p-4">
                      <p className="text-white text-sm">Race day at Autódromo Roberto Mouras #TCCuatromil</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
